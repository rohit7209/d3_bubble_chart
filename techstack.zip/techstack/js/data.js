let data = [
    {
        cat: 'library', name: 'D3', value: 10,
        icon: 'img/d3.svg',
        desc: `
				D3.js (or just D3 for Data-Driven Documents) is a JavaScript library for
				producing dynamic, interactive data visualizations in web browsers.
				It makes use of the widely implemented SVG, HTML5, and CSS standards.<br>
				This infographic you are viewing is made with D3.`
    },
    {
        cat: 'library sub', name: 'Redux', value: 80,
        icon: 'img/redux.svg',
        desc: `
				Redux is an open-source JavaScript library designed for managing
				application state. It is primarily used together with React for building user interfaces.
				Redux is inspired by Facebook’s Flux and influenced by functional programming language Elm.
			`
    },
    {
        cat: 'framework', name: 'Bootstrap CSS', value: 50,
        icon: 'img/bootstrap.svg',
        desc: `
				Bootstrap is a free and open-source front-end web framework for designing websites
				and web applications. It contains HTML-and CSS-based design templates for typography,
				forms, buttons, navigation and other interface components, as well as optional JavaScript extensions.
			`
    },
    {
        cat: 'framework', name: 'ReactJS', value: 100,
        icon: 'img/react.png',
        desc: `
				React (sometimes written React.js or ReactJS) is an open-source JavaScript framework maintained by Facebook for building user interfaces.
				React processes only user interface in applications and can be used in combination with other JavaScript libraries
				or frameworks such as Redux, Flux, Backbone...
			`
    },
    {
        cat: 'tooling', name: 'Google Chrome & Devtool', value: 70,
        icon: 'img/chrome-devtools.svg',
        desc: `
				<strong>Web development tools (devtool)</strong> allow web developers to test and debug their code.
				At Nau, we use the one come with Google Chrome to debug our apps. It is one the the most powerful
				and sophisticated devtool available.
			`
    },
    {
        cat: 'tooling', name: 'Jenkins CI', value: 30,
        icon: 'img/jenkins.png',
        desc: `
				Jenkins is an open source automation server. Jenkins helps to automate the non-human part of
				the whole software development process, with now common things like continuous integration,
				but by further empowering teams to implement the technical part of a Continuous Delivery.
			`
    },
    {
        cat: 'tooling', name: 'Sublime Text 3', value: 100,
        icon: 'img/sublimetext.png',
        desc: `
				Sublime Text 3 is a powerful and cross-platform source code editor. It is well-known for
				introducing the concept of multi-cursor and lots of text editing command. Besides, its
				plugin ecosystem is very rich which allows enhancing productivity to the fullest.
			`
    },
    {
        cat: 'tooling', name: 'Visual Studio Code', value: 50,
        icon: 'img/vscode.png',
        desc: `
				Visual Studio Code is a cross-platform source code editor developed by Microsoft.
				It includes support for debugging, embedded Git control, syntax highlighting,
				intelligent code completion, snippets, and code refactoring. Its extensions eco system is
				growing quickly and it is becoming the best Front End editors out there.
			`
    }, 
    {
        cat: 'tooling', name: 'lite-server', value: 30,
        icon: 'lite-server',
        desc: `
				A Node.js-based developer web server for quickly test apps and web pages with some
				magic of 'auto-reload' on the browser.
			`
    },
    {
        cat: 'backend', name: 'NodeJS', value: 100,
        icon: 'img/nodejs.svg',
        desc: `
				Node.js is a cross-platform JavaScript runtime environment.
				Node.js allows creation of high performance and high concurrency websites with smaller footprint compared to
				other server-side solution. Node.js ecosystem is growing very fast and is trusted by a lot of big companies who
				are adopting it to enhance current products as well as for new ones.
			`
    },
    {
        cat: 'language', name: 'HTML5 & CSS3', value: 100,
        icon: 'img/html5-css3.png',
        desc: `
				The languages of the Web Front End. At Nau, they are in our blood and with them we can build
				world-class websites with any kind of visual effects or designs requested.
			`
    }, 
    {
        cat: 'language', name: 'JavaScript', value: 100,
        icon: 'img/javascript.png',
        desc: `
				JavaScript is the heart of modern Web front end development and essential element of any Single Page
				Applications. In Nau, we invest a good deal in training developers to have good control of this universal language
				and now caplable of developing full stack websites with only JavaScript.
			`
    }, 
    {
        cat: 'language', name: 'SASS (SCSS flavor)', value: 70,
        icon: 'img/sass.png',
        desc: `
				This is our main CSS preprocessor language helping us lay structured foundation to CSS as well
				as assisting on writing more convenient BEM anotations.
			`
    }, 
    {
        cat: 'language', name: 'TypeScript 2', value: 30,
        icon: 'img/typescript.png',
        desc: `
				The strict-typing flavor of ECMAScript, always requires a compiler to compile to vanilla JavaScript
				but the type checking and other syntactical sugar are exceptional. Right now, we only use it for
				Angular 2 projects when needed.
			`
    },
    {
        cat: 'workflow', name: 'Mobile First', value: 100,
        icon: 'Mobile First',
        desc: `
				This is one of our most important principle for web and mobile development.
				More details will be discussed in blog later.
			`
    }, 
    {
        cat: 'workflow', name: 'BabelJS', value: 50,
        icon: 'img/babel.png',
        desc: `
				The de-facto tool to work with ECMAScript 6 and ReactJS nowadays.
			`
    },
    {
        cat: 'workflow', name: 'Front End Code Guide', value: 30,
        icon: 'Front End;Code Guide',
        desc: `
				Based on an existing best practice document for HTML and CSS. We're adopting it as our standards
				and guideline.
			`
    },
    {
        cat: 'workflow', name: 'Gitflow Workflow', value: 70,
        icon: 'img/gitflow.png',
        desc: `
				Our code version control tool is Git, and Gitflow is one of its workflow standard which
				ensure good collaboration and avoid conflict-resolving efforts. For more info, visit: code.naustud.io
			`
    },
    {
        cat: 'workflow', name: 'Webpack', value: 50,
        icon: 'img/gulp.png',
        desc: `
				Webpack is a task automation tool written for Node.js. It is among the most popular
				Front End and Node project automation tools nowadays
			`
    },
    {
        cat: 'workflow', name: 'Webpack', value: 30,
        icon: 'img/webpack.svg',
        desc: `
				A module bundler library that is becoming de-facto tool to use in ReactJS or SPA apps nowadays.
			`
    },
    {
        cat: 'legacy', name: 'jQuery', value: 50,
        icon: 'img/jquery.png',
        desc: `
				Deprecated, because <a href='http://youmightnotneedjquery.com/' target='_blank'>youmightnotneedjquery.com</a>
			`
    },
    {
        cat: 'legacy tooling', name: 'http-server', value: 20,
        icon: 'http-server',
        desc: `
				A quick test web server based on Node.js, deprecated and replaced by live-server.
			`
    }];